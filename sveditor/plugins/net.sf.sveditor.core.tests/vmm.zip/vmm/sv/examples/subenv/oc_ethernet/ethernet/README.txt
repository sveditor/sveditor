
   IMPORTANT  IMPORTANT   IMPORTANT


This version of the Ethernet VIP DOES not compute/check
Ethernet frame CRC correctly. It has been modify to simplify
the example.

You should use the Ethernet VIP found under examples/std_lib/ethernet.

