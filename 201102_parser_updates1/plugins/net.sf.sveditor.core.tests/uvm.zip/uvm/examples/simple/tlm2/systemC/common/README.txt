The files in this directory define a tool-generic API for connecting
SystemC and SystemVerilog sockets together using unique socket identifiers.

The implementation of this API must be provided by the tool vendor.

The API in this example is not part of the Accellera UVM Standard.
